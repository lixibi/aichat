class s{config;constructor(c){this.config=c}}export{s as A};
