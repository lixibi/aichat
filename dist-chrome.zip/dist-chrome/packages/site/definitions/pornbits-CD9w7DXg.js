const t={version:1,id:"pronbits",name:"Pornbits",collaborator:["ian"],tags:["Adult"],type:"private",urls:["https://pornbits.net/","https://pornbits.org/"],isDead:!0};export{t as siteMetadata};
