const e={version:1,id:"hd4free",name:"HD4Free",tags:["影视","综合"],collaborator:["bimzcy"],type:"private",schema:"Unit3D",urls:["https://hd4.xyz/"],isDead:!0};export{e as siteMetadata};
