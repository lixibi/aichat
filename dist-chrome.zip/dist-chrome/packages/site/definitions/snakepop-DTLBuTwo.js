const a={version:1,id:"snakepop",name:"Snakepop",tags:["音乐"],collaborator:["timyuan"],type:"private",schema:"GazelleJSONAPI",urls:["https://snakepop.art/"],isDead:!0};export{a as siteMetadata};
