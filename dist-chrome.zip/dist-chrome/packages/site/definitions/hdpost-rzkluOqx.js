const t={version:1,id:"hdpost",name:"HDPOST",tags:["电影","电视剧"],type:"private",schema:"Unit3D",urls:["https://pt.hdpost.top/"],isDead:!0};export{t as siteMetadata};
