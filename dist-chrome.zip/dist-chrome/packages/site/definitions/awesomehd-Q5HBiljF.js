const e={version:1,id:"awesomehd",name:"Awesome-HD",aka:["AHD"],tags:["影视"],type:"private",schema:"Gazelle",urls:["https://awesome-hd.me/"],isDead:!0};export{e as siteMetadata};
