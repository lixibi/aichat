const e={version:1,id:"hdstreet",name:"高清街",description:"高清街专注于华语影视俱乐部",collaborator:["wyl219"],type:"private",schema:"NexusPHP",urls:["https://hdstreet.club/"],isDead:!0};export{e as siteMetadata};
