const e={version:1,id:"yingk",name:"影客",aka:["影客PT","YingkPT","美盒子","MeiHeZi"],tags:["影视","综合"],type:"private",schema:"NexusPHP",urls:["https://yingk.com/"],isDead:!0};export{e as siteMetadata};
