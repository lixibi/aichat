var i=(d=>(d[d.unknown=0]="unknown",d[d.downloading=1]="downloading",d[d.seeding=2]="seeding",d[d.inactive=3]="inactive",d[d.completed=4]="completed",d))(i||{});export{i as E};
