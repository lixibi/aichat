function c(e,n){const t=new Set(n);return e.filter(r=>!t.has(r))}export{c as d};
