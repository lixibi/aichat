function i(e,c){const r={};for(let t=0;t<c.length;t++){const n=c[t];Object.hasOwn(e,n)&&(r[n]=e[n])}return r}export{i as p};
