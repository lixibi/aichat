import{j as r,g as o}from"./differenceInYears-DYNR6-gz.js";function i(n,d,e){const f=r(n,d,e)/7;return o(e?.roundingMethod)(f)}export{i as d};
