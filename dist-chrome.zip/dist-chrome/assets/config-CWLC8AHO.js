const o=["auto","light","dark"],e=["web","browser","extension"];export{e as L,o as s};
