function i(e,t){const n=new Set(t);return e.filter(r=>n.has(r))}export{i};
