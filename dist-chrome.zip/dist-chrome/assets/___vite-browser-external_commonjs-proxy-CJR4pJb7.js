import{bD as e}from"../packages/site/index-DXMpdCZt.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
