function u(e,c){const t={};for(let n=0;n<e.length;n++){const s=e[n],o=c(s);t[o]=(t[o]??0)+1}return t}export{u as c};
