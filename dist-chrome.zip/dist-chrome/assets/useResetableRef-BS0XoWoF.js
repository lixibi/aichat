import{$ as r,H as l,G as n}from"../packages/site/index-DXMpdCZt.js";function R(e,t={}){const{shallow:a=!1}=t,s=r(e),o=a?l(s):n(s);return{ref:o,reset:(f=e)=>{o.value=r(f)}}}export{R as u};
