import{a_ as o}from"../packages/site/index-DXMpdCZt.js";import{m as t}from"./merge-XRWDHhwH.js";function n(e,r){return t(o(e),r)}export{n as t};
